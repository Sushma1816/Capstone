package com.dyvak.authentication.service;

import com.dyvak.authentication.domain.User;

public interface UserService {

    void create(User user);
}
