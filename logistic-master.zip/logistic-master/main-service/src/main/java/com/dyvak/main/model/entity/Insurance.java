package com.dyvak.main.model.entity;

public interface Insurance {
}
