package com.dyvak.main.model.dto;

public class DriverCertificateDto {
}
