package com.dyvak.main.model.dto;

public class TransportInsuranceDto {
}
