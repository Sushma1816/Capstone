package com.dyvak.main.model.entity.enums;

public enum CargoCategory {


}
